<?php

namespace App\Modules\Tour\Models;

use Illuminate\Database\Eloquent\Model;

class TourType extends Model
{
    //
}
