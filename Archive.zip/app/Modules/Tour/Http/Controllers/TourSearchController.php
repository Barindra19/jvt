<?php

namespace App\Modules\Tour\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use Illuminate\Support\Facades\Validator;

use App\Modules\Tour\Models\Tour as TourModel;
use App\Modules\Tour\Models\TourBanner as TourBannerModel;
use App\Modules\Tour\Models\TourType as TourTypeModel;

use Auth;
use Theme;
use Entrust;
use Activity;
use File;


class TourSearchController extends Controller
{

    protected $_data = array();
    protected $bannerPath = array();

    public function __construct()
    {
        $this->middleware(['permission:layanan-menu']);
        $this->middleware(['permission:tour-menu']);

        $this->urlBanner                                = '/media/banner/';
        $this->bannerPath                               = public_path($this->urlBanner);


        $this->_data['MenuActive']                      = 'Cari Paket';
        $this->_data['form_name']                       = 'search';
    }

    public function show(){
        $this->_data['state']                           = 'form';
        $this->_data['MenuDescription']                 = 'Temukan Paket Tour Sesuai keinginanmu';

        return Theme::view('modules.tour.search.show',$this->_data);
    }

    public function search(Request $request){
        $this->_data['state']                           = 'search';
        $this->_data['MenuDescription']                 = 'Temukan Paket Tour Sesuai keinginanmu';
        $Type                                           = $request->type;

        $this->_data['Type']                            = $request->type;
        $this->_data['Region']                          = $request->region;
        $this->_data['Country']                         = $request->country;
        $this->_data['Destination']                     = $request->destination;

        if($Type == 1){ // HOT OFFER //
            $Tours                                      = "";

        }else if($Type == 2){ // PRVATE TRIP
            $Tours                                      = "";

        }else if($Type == 3){ // OPEN TRIP
            $Where                                      = array(
                'is_active'                             => 1
            );

            if($request->regional){
                $Where['regional_id']                   = $request->regional;
            }
            if($request->country){
                $Where['country_id']                    = $request->country;
            }
            if($request->destination){
                $Where['destination_id']                = $request->destination;
            }
            $Tours                                      = TourModel::where($Where)->get();
        }else if($Type == 4){ // CUSTOME TRIP
            $Tours                                      = "";
        }else{
            $Tours                                      = "";
        }

        $this->_data['Tours']                           = $Tours;

        return Theme::view('modules.tour.search.show',$this->_data);
    }

}
