<?php

namespace App\Modules\Region\Providers;

use Caffeinated\Modules\Support\ServiceProvider;

class ModuleServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap the module services.
     *
     * @return void
     */
    public function boot()
    {
        $this->loadTranslationsFrom(__DIR__.'/../Resources/Lang', 'region');
        $this->loadViewsFrom(__DIR__.'/../Resources/Views', 'region');
        $this->loadMigrationsFrom(__DIR__.'/../Database/Migrations', 'region');
    }

    /**
     * Register the module services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->register(RouteServiceProvider::class);
    }
}
