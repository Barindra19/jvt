<?php

namespace App\Modules\Region\Models;

use Illuminate\Database\Eloquent\Model;

class Region extends Model
{
    //
}
