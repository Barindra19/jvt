<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| This file is where you may define all of the routes that are handled
| by your module. Just tell Laravel the URIs it should respond
| to using a Closure or controller method. Build something great!
|
*/

Route::group(['prefix' => 'country','middleware' => 'auth'], function () {

    Route::post('/searchbyregion','CountryController@searchbyregion')->name('country_searchbyregion');
//    Route::post('/searchbytreatment','TreatmentPackageController@searchbytreatment')->name('treatmentcategory_searchbytreatment');
//    Route::post('/getdetailpackage','TreatmentPackageController@getdetailpackage')->name('treatmentcategory_getdetailpackage');
});
