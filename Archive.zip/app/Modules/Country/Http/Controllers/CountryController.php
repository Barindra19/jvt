<?php

namespace App\Modules\Country\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\Modules\Country\Models\Country as CountryModel;


use Auth;
use Theme;
use Entrust;
use Activity;

class CountryController extends Controller
{
    protected $_data = array();
    public function __construct()
    {
        $this->_data['MenuActive']                      = 'Country';
        $this->_data['form_name']                       = 'country';
    }

    public function searchbyregion(Request $request){
        $RegionID                                       = $request->region_id;

        $Where                                          = array(
            "is_active"                                 => 1,
            "region_id"                                 => $RegionID,
        );
        $Country                                        = CountryModel::where($Where)->orderBy('name')->get();
            echo '<option value="0">Pilih Negara</option>';
        foreach($Country as $item){
            echo '<option value="'.$item->id.'">' . $item->name . '</option>';
        }
    }
}
