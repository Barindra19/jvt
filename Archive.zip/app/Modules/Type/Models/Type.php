<?php

namespace App\Modules\Type\Models;

use Illuminate\Database\Eloquent\Model;

class Type extends Model
{
    //
}
