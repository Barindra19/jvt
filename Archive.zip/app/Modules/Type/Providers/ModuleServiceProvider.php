<?php

namespace App\Modules\Type\Providers;

use Caffeinated\Modules\Support\ServiceProvider;

class ModuleServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap the module services.
     *
     * @return void
     */
    public function boot()
    {
        $this->loadTranslationsFrom(__DIR__.'/../Resources/Lang', 'type');
        $this->loadViewsFrom(__DIR__.'/../Resources/Views', 'type');
        $this->loadMigrationsFrom(__DIR__.'/../Database/Migrations', 'type');
    }

    /**
     * Register the module services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->register(RouteServiceProvider::class);
    }
}
