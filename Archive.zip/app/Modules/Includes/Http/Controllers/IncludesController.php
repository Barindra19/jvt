<?php

namespace App\Modules\Includes\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class IncludesController extends Controller
{
    //
}
