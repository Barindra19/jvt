<?php

namespace App\Modules\Destination\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\Modules\Destination\Models\Destination as DesinationModel;

use Auth;
use Theme;
use Entrust;
use Activity;

class DestinationController extends Controller
{
    protected $_data = array();
    public function __construct()
    {
        $this->_data['MenuActive']                      = 'Destination';
        $this->_data['form_name']                       = 'destination';
    }

    public function searchbycountry(Request $request){
        $RegionID                                       = $request->region_id;
        $CountryID                                      = $request->country_id;

        $Where                                          = array(
            "is_active"                                 => 1,
            "region_id"                                 => $RegionID,
            "country_id"                                => $CountryID
        );
        $Destination                                    = DesinationModel::where($Where)->orderBy('name')->get();

        echo '<option value="0">Pilih Destinasi</option>';
        foreach($Destination as $item){
            echo '<option value="'.$item->id.'">' . $item->name . '</option>';
        }
    }
}
